This is a demo version of Finesse for personal use only! some important glyphs are not included. ►►► Purchase the full version at https://goicha.org/downloads/goichas-font-bundle/

any donation is very appreciated.
►►► Paypal account for donation : paypal.me/goicha


